# Qual 4 base API

## Technologies Used

1. **_NodeJS_** - Platform
2. **_Express_** - Framework
3. **_JavaScript_** - Programming Language
4. **_SQLite_** - Database
5. **_Sequelize_** - ORM
